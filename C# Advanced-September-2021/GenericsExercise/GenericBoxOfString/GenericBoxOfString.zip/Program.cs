﻿using System;

namespace GenericBoxOfString
{
    public class Program
    {
        static void Main(string[] args)
        {
            Box<string> strBox = new Box<string>();

            var n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string str = Console.ReadLine();

                strBox.Add(str);
            }

            Console.WriteLine(strBox);
        }
    }
}
