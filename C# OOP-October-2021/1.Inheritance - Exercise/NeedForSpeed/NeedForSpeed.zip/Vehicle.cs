﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Vehicle
    {
        public Vehicle(int horsePower, double fuel)
        {
            HorsePower = horsePower;
            Fuel = fuel;
        }


        public double DefaultFuelConsumption
        {
            get => DefaultFuelConsumption = 1.25;
            private set { }
        }

        public virtual double FuelConsumption { get => FuelConsumption = DefaultFuelConsumption; set { } }

        public double Fuel { get; set; }

        public int HorsePower { get; set; }

        public virtual void Drive(double kilometers)
        {
            var travelledKilometers = kilometers * FuelConsumption;

            Fuel -= travelledKilometers;
        }
    }
}
