﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Cars
{
    public class TunerCar : Car
    {
        private const double fuelAvailable = 65;
        private const double fuelConsumptionPerRace = 7.5;


        public TunerCar(string make, string model, string vin, int horsePower)
            : base(make, model, vin, horsePower, fuelAvailable, fuelConsumptionPerRace)
        {

        }

        public override void Drive()
        {
            this.FuelAvailable -= fuelConsumptionPerRace;
            this.HorsePower -= (int)(Math.Round(HorsePower * 0.97));
        }
    }
}
