﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer : Product, IComputer
    {
        private List<IComponent> components;
        private List<IPeripheral> peripherals;
        private double overallPerformance;
        private decimal price;

        protected Computer(int id, string manufacturer, string model, decimal price, double overallPerformance)
            : base(id, manufacturer, model, price, overallPerformance)
        {
            this.overallPerformance = overallPerformance;
            this.price = price;
        }

        public double OverallPerformance
        {
            get => this.overallPerformance;
            protected set
            {
                if (this.components.Count == 0)
                {
                    this.OverallPerformance = overallPerformance;
                }
                else
                {
                    foreach (IComponent component in this.components)
                    {
                        OverallPerformance += component.OverallPerformance;
                    }

                    OverallPerformance += this.overallPerformance;
                }
            }
        }

        public decimal Price
        {
            get => this.price;
            private set
            {
                Price += this.price;
                foreach (IComponent component in this.components)
                {
                    Price += component.Price;
                }
            }
        }

        public IReadOnlyCollection<IComponent> Components { get => this.components; }
        public IReadOnlyCollection<IPeripheral> Peripherals { get => this.peripherals; }
        public void AddComponent(IComponent component)
        {

            if (this.components.FirstOrDefault(x => x.GetType().Name == component.GetType().Name) != null)
            {
                throw new ArgumentException($"Component {component.GetType().Name} already exists in {this.GetType().Name} with Id {Id}.");
            }

            this.components.Add(component);
        }

        public IComponent RemoveComponent(string componentType)
        {
            if (this.components.Count == 0)
            {
                throw new ArgumentException($"Component {componentType} does not exist in {this.GetType().Name} with Id {Id}.");
            }

            var component = this.components.FirstOrDefault(component => component.GetType().Name == componentType);

            if (component is null)
            {
                throw new ArgumentException($"Component {componentType} does not exist in {this.GetType().Name} with Id {Id}.");
            }

            this.components.Remove(component);

            return component;
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            if (this.components.FirstOrDefault(x => x.GetType().Name == peripheral.GetType().Name) != null)
            {
                throw new ArgumentException($"Peripheral {peripheral.GetType().Name} already exists in {this.GetType().Name} with Id {Id}.");
            }

            this.peripherals.Add(peripheral);
        }

        public IPeripheral RemovePeripheral(string peripheralType)
        {
            if (this.peripherals.Count == 0)
            {
                throw new ArgumentException($"Peripheral {peripheralType} does not exist in {this.GetType().Name} with Id {Id}.");
            }

            var peripheral = this.peripherals.FirstOrDefault(peripheral => peripheral.GetType().Name == peripheralType);

            if (peripheral is null)
            {
                throw new ArgumentException($"Peripheral {peripheralType} does not exist in {this.GetType().Name} with Id {Id}.");
            }

            this.peripherals.Remove(peripheral);

            return peripheral;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Overall Performance: {OverallPerformance}. Price: {Price} - {this.GetType().Name}: {Manufacturer} {Model} (Id: {Id})");

            sb.AppendLine($" Components ({this.components.Count}):");

            foreach (IComponent component in Components)
            {
                sb.AppendLine(component.ToString());
            }

            sb.AppendLine($" Peripherals ({this.Peripherals.Count}); Average Overall Performance ({this.peripherals.Average(peripheral => peripheral.OverallPerformance)}):");

            foreach (IPeripheral peripheral in Peripherals)
            {
                sb.AppendLine(peripheral.ToString());
            }

            return sb.ToString().TrimEnd();
        }
    }
}
