﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> allIdentifiables = new List<IIdentifiable>();
            List<IBirthdable> allBirthdables = new List<IBirthdable>();

            string input = Console.ReadLine();

            while (input != "End")
            {
                string[] tokens = input.Split();

                string type = tokens[0];
                // citizen
                if (type == "Citizen")
                {
                    string name = tokens[1];
                    int age = int.Parse(tokens[2]);
                    string id = (tokens[3]);
                    string birthday = tokens[4];

                    Citizen citizen = new Citizen(name, age, id, birthday);

                    allIdentifiables.Add(citizen);
                    allBirthdables.Add(citizen);
                }
                else if (type == "Robot") //robot
                {
                    string model = tokens[1];
                    string id = (tokens[2]);

                    Robot robot = new Robot(model, id);

                    allIdentifiables.Add(robot);
                }
                else if (type == "Pet")
                {
                    string name = tokens[1];
                    string birthday = tokens[2];

                    Pet pet = new Pet(name, birthday);

                    allBirthdables.Add(pet);

                }

                input = Console.ReadLine();
            }

            string lastDigitsOfFakeIds = Console.ReadLine();

            foreach (var members in allBirthdables)
            {
                if (members.Birthdate.EndsWith(lastDigitsOfFakeIds))
                {
                    Console.WriteLine(members.Birthdate);
                }
            }

        }
    }
}
