﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Easter.Models.Bunnies.Contracts;
using Easter.Repositories.Contracts;

namespace Easter.Repositories
{
    public class BunnyRepository : IRepository<IBunny>
    {
        private HashSet<IBunny> bunnies;

        public IReadOnlyCollection<IBunny> Models { get => this.bunnies; }
        public void Add(IBunny model)
        {
            this.bunnies.Add(model);
        }

        public bool Remove(IBunny model)
        {
            return this.bunnies.Remove(model);
        }

        public IBunny FindByName(string name)
        {
            var bunny = this.bunnies.FirstOrDefault(b => b.Name == name);

            return bunny;
        }
    }
}
