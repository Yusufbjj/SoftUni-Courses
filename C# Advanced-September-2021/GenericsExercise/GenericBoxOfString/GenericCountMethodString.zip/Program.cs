﻿using System;
using System.Linq;

namespace GenericBoxOfString
{
    public class Program
    {
        static void Main(string[] args)
        {
            Box<string> strBox = new Box<string>();

            var n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string input = (Console.ReadLine());

                strBox.Add(input);
            }

            string itemToCompare = Console.ReadLine();

            int result = strBox.CountGreaterThan(itemToCompare);

            Console.WriteLine(result);

        }
    }
}
