﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            "Server=localhost;User=sa;Password=9215092017a;Database=MusicHub;";
    }
}
