﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IBirthdable
    {
        public string Birthdate { get; }
    }
}
