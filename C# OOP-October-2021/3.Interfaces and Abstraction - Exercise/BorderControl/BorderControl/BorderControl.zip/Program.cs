﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> allIdentifiables = new List<IIdentifiable>();

            string input = Console.ReadLine();

            while (input != "End")
            {
                string[] tokens = input.Split();

                // citizen
                if (tokens.Length == 3)
                {
                    string name = tokens[0];
                    int age = int.Parse(tokens[1]);
                    string id = (tokens[2]);

                    Citizen citizen = new Citizen(name, age, id);

                    allIdentifiables.Add(citizen);
                }
                else //robot
                {
                    string model = tokens[0];
                    string id = (tokens[1]);

                    Robot robot = new Robot(model, id);

                    allIdentifiables.Add(robot);
                }

                input = Console.ReadLine();
            }

            string lastDigitsOfFakeIds = Console.ReadLine();

            foreach (var members in allIdentifiables)
            {
                if (members.Id.EndsWith(lastDigitsOfFakeIds))
                {
                    Console.WriteLine(members.Id);
                }
            }

        }
    }
}
