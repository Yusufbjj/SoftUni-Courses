﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Citizen : IIdentifiable,IBirthdable
    {
        private string name;

        private int age;


        public Citizen(string name, int age, string id,string birthdate)
        {
            this.name = name;
            this.age = age;
            Id = id;
            this.Birthdate = birthdate;
        }
        public string Id { get; private set; }
        public string Birthdate { get; private set; }
    }
}
