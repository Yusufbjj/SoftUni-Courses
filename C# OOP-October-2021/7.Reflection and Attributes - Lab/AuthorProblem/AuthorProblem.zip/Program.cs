﻿using System;

namespace AuthorProblem
{
    [Author("Az")]
    [Author("ti")]
    [Author("tq")]
    public class StartUp
    {
        [Author("Gosho")]
        public static void Main(string[] args)
        {

        }
    }


}
