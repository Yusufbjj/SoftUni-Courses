﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Easter.Models.Eggs;
using Easter.Models.Eggs.Contracts;
using Easter.Repositories.Contracts;

namespace Easter.Repositories
{
    public class EggRepository : IRepository<IEgg>
    {
        private HashSet<IEgg> eggs;

        public IReadOnlyCollection<IEgg> Models
        {
            get => this.eggs;
        }
        public void Add(IEgg model)
        {
            this.eggs.Add(model);
        }

        public bool Remove(IEgg model)
        {
            return this.eggs.Remove(model);
        }

        public IEgg FindByName(string name)
        {
            var egg = this.eggs.FirstOrDefault(e => e.Name == name);

            return egg;
        }
    }
}
